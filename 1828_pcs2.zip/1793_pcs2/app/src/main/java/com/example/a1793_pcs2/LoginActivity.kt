package com.example.a1793_pcs2

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.a1793_pcs2.api.BaseRetrofit
import com.example.a1793_pcs2.utils.SessionManager
import com.google.android.material.textfield.TextInputEditText

class LoginActivity : AppCompatActivity() {
    companion object{
        lateinit var sessionManager:SessionManager
        private lateinit var context:Context

    }
    private val api by lazy { BaseRetrofit().endpoint }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        sessionManager=SessionManager(this)

        val loginStatus= sessionManager.getBoolean("LOGIN_STATUS")
        if(loginStatus){
            val moveIntent=Intent(this@LoginActivity,MainActivity::class.java)
            startActivity(moveIntent)
            finish()
        }
        val btnLogin=findViewById(R.id.btnLogin)as Button
        val txtEmail=findViewById(R.id.txtEmail)as TextInputEditText
    }
}