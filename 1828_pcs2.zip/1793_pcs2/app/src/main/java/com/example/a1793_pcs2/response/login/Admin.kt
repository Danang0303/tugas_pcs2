package com.example.a1793_pcs2.response.login

class Admin (
    val id:String,
    val email:String,
    val password:String,
    val nama:String
)