package com.example.a1793_pcs2.response.login

class Data (
    val admin:Admin,
    val token:String
)